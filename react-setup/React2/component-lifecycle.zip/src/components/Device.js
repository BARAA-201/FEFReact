import React from 'react'

class Device extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            value: 5
        }
    }
    componentWillMount() {
        console.log('Device - componentWillMount')
    }
    componentDidMount() {
        console.log('Device - componentDidMount')
    }
    componentWillReceiveProps(nextProps) {
        console.log('Device - componentWillReceiveProps')
    }
    shouldComponentUpdate(nextProps, nextState) {
        console.log('Device - shouldComponentUpdate')
        console.log(this.state)
        console.log(nextState)
        if (this.state.value == nextState.value && this.props.deviceWarranty == nextProps.deviceWarranty) {
            return false
        }
        return true
    }
    componentWillUpdate() {
        console.log('Device - componentWillUpdate')
    }
    componentDidUpdate() {
        console.log('Device - componentDidUpdate')
    }
    componentWillUnmount() {
        console.log('Device - componentWillUnmount')
    }
    changeStateRandomly() {
        this.setState({value: 7})
    }
    render() {
        return (
            <div>
                <h4><strong>{this.props.laptop.device}</strong></h4>
                <div>{this.props.laptop.year}</div>
                <div>{this.props.deviceWarranty}</div>
                <input type='button' value="Change Device State" onClick={this.changeStateRandomly.bind(this)} />
            </div>
        )
    }
}

export default Device 