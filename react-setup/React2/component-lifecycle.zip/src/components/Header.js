import React from 'react'

const Header = ({title}) => {
    return (
        <header>
            <a href="/">Home</a>&nbsp;
            <a href="/about">About</a>&nbsp;
            <a href="/topics">Topics</a>
            <h1>{title}</h1>
        </header>
    )
}

export default Header