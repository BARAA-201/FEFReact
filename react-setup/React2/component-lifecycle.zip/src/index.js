import React from 'react'
import ReactDOM from 'react-dom'
import Home from './screens/Home'
import About from './screens/About'
import Topics from './screens/Topics'
import Laptops from './screens/Laptops'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'

const App = () => {
    return (
        <div>
            <Router>
                <div>
                    <ul>
                        <li>
                            <Link to='/' title='Go Home'>Home</Link>
                        </li>
                        <li>
                            <Link to='/about'>About</Link>
                        </li>
                        <li>
                            <Link to='/topics'>Topics</Link>
                        </li>
                        <li>
                            <Link to='/laptops'>Laptops</Link>
                        </li>
                    </ul>
                    <Route path='/' component={Home} exact />
                    <Route path='/about' component={About} />
                    <Route path='/topics' component={Topics} />
                    <Route path='/laptops' component={Laptops} />
                </div>
            </Router>
        </div>
    )
}

ReactDOM.render(<App />, document.getElementById('root'))