import React from 'react'
import Device from '../components/Device'
import { filterDevicesByYear as dvfltr } from '../lib/functions'
class Laptops extends React.Component {
    constructor(props) {
        super(props)
        this.laptops = [
            {
                device: 'Dell',
                year: 2022
            },
            {
                device: 'HP',
                year: 2019
            },
            {
                device: 'Apple',
                year: 2020
            },
            {
                device: 'Toshiba',
                year: 2010
            }
        ];
        this.state = {
            deviceWarranty: 2
        }
        this.modernDevices = dvfltr(this.laptops, 2020)
    }
    changeWarranty() {
        this.setState({
            deviceWarranty: 3
        })
    }
    render() {
        return (
            <div>
                <h2>Devices</h2>
                {this.modernDevices.map((laptop, i) => {
                    return <Device deviceWarranty={this.state.deviceWarranty} laptop={laptop} key={i} />
                })}
                <input type="button" value="Change Warranty" onClick={this.changeWarranty.bind(this)} />
            </div>
        )
    }
}

export default Laptops