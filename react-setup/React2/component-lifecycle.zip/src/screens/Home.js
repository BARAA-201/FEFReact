import React from 'react'

class Home extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return (
            <div>
                <h2>Home</h2>
            </div>
        )
    }
}

export default Home