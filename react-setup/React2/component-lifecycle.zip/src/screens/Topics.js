import React from 'react'
import {Route, Link} from 'react-router-dom'
import Topic from './Topic'

const Topics = ({match}) => {
    
    return (
        <div>
            <h2>Topics</h2>
            <ul>
                <li><Link to={`${match.url}/learn-react`}>Learn React</Link></li>
                <li><Link to={`${match.url}/learn-angular`}>Learn Angular</Link></li>
                <li><Link to={`${match.url}/learn-node`}>Learn Node</Link></li>
            </ul>
            <Route path={`${match.url}/:topicId`} component={Topic} />
        </div>
    )
}

export default Topics